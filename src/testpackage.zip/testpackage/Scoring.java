package testpackage;
// This enum is the limit of the types of scoring we are doing in this game.
// If its not on this list, you can't score it that way.
public enum Scoring {
	YATZY, PAIR, TWOPAIR, THREEOFAKIND, FOUROFAKIND, SMALLSTRAIGHT, LARGESTRAIGHT, FULLHOUSE;
}